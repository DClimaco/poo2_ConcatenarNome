﻿namespace Aula20240805
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSobrenome = new System.Windows.Forms.Label();
            this.txbNome = new System.Windows.Forms.TextBox();
            this.txbSobrenome = new System.Windows.Forms.TextBox();
            this.lblApresentacao = new System.Windows.Forms.Label();
            this.txbNomeCompleto = new System.Windows.Forms.TextBox();
            this.btnConcatenar = new System.Windows.Forms.Button();
            this.cbxNomesAdicionados = new System.Windows.Forms.ComboBox();
            this.lblSelecionado = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome.Location = new System.Drawing.Point(12, 16);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(55, 20);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = "Nome:";
            // 
            // lblSobrenome
            // 
            this.lblSobrenome.AutoSize = true;
            this.lblSobrenome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSobrenome.Location = new System.Drawing.Point(12, 49);
            this.lblSobrenome.Name = "lblSobrenome";
            this.lblSobrenome.Size = new System.Drawing.Size(96, 20);
            this.lblSobrenome.TabIndex = 1;
            this.lblSobrenome.Text = "Sobrenome:";
            // 
            // txbNome
            // 
            this.txbNome.Location = new System.Drawing.Point(73, 16);
            this.txbNome.Name = "txbNome";
            this.txbNome.Size = new System.Drawing.Size(338, 20);
            this.txbNome.TabIndex = 2;
            // 
            // txbSobrenome
            // 
            this.txbSobrenome.Location = new System.Drawing.Point(114, 49);
            this.txbSobrenome.Name = "txbSobrenome";
            this.txbSobrenome.Size = new System.Drawing.Size(296, 20);
            this.txbSobrenome.TabIndex = 3;
            // 
            // lblApresentacao
            // 
            this.lblApresentacao.AutoSize = true;
            this.lblApresentacao.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblApresentacao.Location = new System.Drawing.Point(13, 124);
            this.lblApresentacao.Name = "lblApresentacao";
            this.lblApresentacao.Size = new System.Drawing.Size(168, 20);
            this.lblApresentacao.TabIndex = 4;
            this.lblApresentacao.Text = "Seu nome completo é:";
            // 
            // txbNomeCompleto
            // 
            this.txbNomeCompleto.Location = new System.Drawing.Point(17, 147);
            this.txbNomeCompleto.Name = "txbNomeCompleto";
            this.txbNomeCompleto.ReadOnly = true;
            this.txbNomeCompleto.Size = new System.Drawing.Size(394, 20);
            this.txbNomeCompleto.TabIndex = 5;
            // 
            // btnConcatenar
            // 
            this.btnConcatenar.Location = new System.Drawing.Point(335, 85);
            this.btnConcatenar.Name = "btnConcatenar";
            this.btnConcatenar.Size = new System.Drawing.Size(75, 23);
            this.btnConcatenar.TabIndex = 6;
            this.btnConcatenar.Text = "Concatenar";
            this.btnConcatenar.UseVisualStyleBackColor = true;
            this.btnConcatenar.Click += new System.EventHandler(this.btnConcatenar_Click);
            // 
            // cbxNomesAdicionados
            // 
            this.cbxNomesAdicionados.FormattingEnabled = true;
            this.cbxNomesAdicionados.Location = new System.Drawing.Point(17, 224);
            this.cbxNomesAdicionados.Name = "cbxNomesAdicionados";
            this.cbxNomesAdicionados.Size = new System.Drawing.Size(393, 21);
            this.cbxNomesAdicionados.TabIndex = 7;
            this.cbxNomesAdicionados.SelectedIndexChanged += new System.EventHandler(this.cbxNomesAdicionados_SelectedIndexChanged);
            // 
            // lblSelecionado
            // 
            this.lblSelecionado.AutoSize = true;
            this.lblSelecionado.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelecionado.Location = new System.Drawing.Point(147, 266);
            this.lblSelecionado.Name = "lblSelecionado";
            this.lblSelecionado.Size = new System.Drawing.Size(111, 25);
            this.lblSelecionado.TabIndex = 8;
            this.lblSelecionado.Text = "<<vazio>>";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(439, 323);
            this.Controls.Add(this.lblSelecionado);
            this.Controls.Add(this.cbxNomesAdicionados);
            this.Controls.Add(this.btnConcatenar);
            this.Controls.Add(this.txbNomeCompleto);
            this.Controls.Add(this.lblApresentacao);
            this.Controls.Add(this.txbSobrenome);
            this.Controls.Add(this.txbNome);
            this.Controls.Add(this.lblSobrenome);
            this.Controls.Add(this.lblNome);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSobrenome;
        private System.Windows.Forms.TextBox txbNome;
        private System.Windows.Forms.TextBox txbSobrenome;
        private System.Windows.Forms.Label lblApresentacao;
        private System.Windows.Forms.TextBox txbNomeCompleto;
        private System.Windows.Forms.Button btnConcatenar;
        private System.Windows.Forms.ComboBox cbxNomesAdicionados;
        private System.Windows.Forms.Label lblSelecionado;
    }
}

